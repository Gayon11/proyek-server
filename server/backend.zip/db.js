const { Pool } = require("pg");
require("dotenv").config();

// TUGAS KAMU:
// Hapus teks "PASTE_LINK_DARI_NOTEPAD_DISINI" di bawah ini.
// Ganti dengan Link Panjang dari Notepad (yang passwordnya sudah Jakarta2025 & Port 6543).

const connectionString = "postgresql://postgres.buwsqlxnivulzfyzpmoi:Kppr0j3k123@aws-1-ap-southeast-1.pooler.supabase.com:6543/postgres";

const pool = new Pool({
  connectionString: connectionString,
  ssl: {
    rejectUnauthorized: false, // Wajib untuk Supabase
  },
});

// Tes Koneksi
pool.query("SELECT NOW()", (err, res) => {
  if (err) {
    console.error("❌ Gagal konek! Cek linknya lagi:", err.message);
  } else {
    console.log("✅ SUKSES! Database Baru Siap Digunakan.", res.rows[0].now);
  }
});

module.exports = pool;
